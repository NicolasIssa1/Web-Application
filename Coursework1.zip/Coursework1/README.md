## Setup Instructions

1. Clone or download this repository.
2. Navigate to the `Coursework1` directory.

export FLASK_APP=/workspaces/Web-Application/Coursework1/run.py

export FLASK_ENV=development

flask run
